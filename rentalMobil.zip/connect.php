<?php 
 
$koneksi = mysqli_connect("localhost","id18234133_fido","Password123#","id18234133_rentalmobil_apk");
 
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
 
?>