<?php
require_once "config/koneksi.php";
?>