<h3 class="page-heading mb-4">Dashboard</h3>
<div class="row mb-2">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-body">
        <h3>Selamat Datang di Aplikasi Rental Mobil</h3>
        <center><img src="images/mbl.png" alt=""></center>
        <p>Semangat Bekerja Gaes</p>
      </div>
    </div>
  </div>
</div>
</div>